#ifndef LISTA_ENLAZADA_HPP
#define LISTA_ENLAZADA_HPP
#include "nodo.hpp"
#include <iostream>
template<typename T>
class ListaEnlazada {
private:
  Nodo<T> *apPrimero;
  Nodo<T> *apUltimo;
  int cantidad;
public:
     ListaEnlazada() 
    {
        apPrimero = nullptr;
        apUltimo = nullptr;
        cantidad = 0;
    }
    ~ListaEnlazada() 
    {
        for (int i = 0; i < cantidad; i++) {
        delete this->obtener(i);
        }
        apPrimero = nullptr;
        apUltimo = nullptr;
    }
    //Obtiene el valor de un nodo en la posicion deseada

    int largo_lista()
    {
        //std::cout << cantidad << std::endl;;
        return cantidad;
    }

  void eliminar(int indice) {
    if (indice < 0 || indice >= cantidad) {
        std::cout << "Indice fuera de rango  o no pertecene" << std::endl;
    }
    Nodo<T> *nodoAEliminar = obtener(indice);

    if (nodoAEliminar->obtenerAnterior() != nullptr) {
        // Obtiene el valor del nodo anterior al nodo a eliminar
        // Establece como siguiente del nodo anterior al que se quiere eliminar 
        //El nodo siguiente al nodo a eliminar
        nodoAEliminar->obtenerAnterior()->establecerSiguiente(nodoAEliminar->obtenerSiguiente()); 
    } else { //Si el indice indicado pertenece a la primera posicion de la lista entonces el valor del puntero inicial pasa a ser el del nodo en la segunda posicion
        apPrimero = nodoAEliminar->obtenerSiguiente();
    }

    if (nodoAEliminar->obtenerSiguiente() != nullptr) {
        nodoAEliminar->obtenerSiguiente()->establecerAnterior(nodoAEliminar->obtenerAnterior());
    } else {
        apUltimo = nodoAEliminar->obtenerAnterior();
    }
    cantidad--;
    }

    void insertar(T dato)
    {
        Nodo<T> *nuevoNodo = new Nodo<T>(dato);
        if (apUltimo == nullptr) //Si la lista esta vacia
        {
            apPrimero = nuevoNodo;
            apUltimo = nuevoNodo;
        }
        else
        {
            apUltimo->establecerSiguiente(nuevoNodo);
            apUltimo = nuevoNodo;
        }
        cantidad++;
    }
    Nodo<T>* obtener(int indice) 
    {
        Nodo<T> *nodo = apPrimero;
        while (indice != 0 && nodo != nullptr) 
        {
         nodo = nodo->obtenerSiguiente();
         indice--;
        }

    return nodo;
    }

    void modificar(T dato, int indice) {
        this->obtener(indice)->establecerDato(dato);
  }
};
#endif