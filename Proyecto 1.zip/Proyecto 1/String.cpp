#include <iostream>
#include <cstdlib>
#include "String.hpp"
using namespace std;
String::String(char*varTexto)
{
    int cantidad = 0;
    this->Texto = new ListaEnlazada<char>();
    while(varTexto[cantidad] != '\0')
    {
        this->Texto->insertar(varTexto[cantidad]);
        cantidad +=1;
    }

}
String::~String(){}

void String::cambiarCadena(char* nuevaCadena)
{
    int cont = 0;
    while (nuevaCadena[cont] != '\0')
    {
        this->Texto->modificar(nuevaCadena[cont],cont);
        cont++;
    }
}
void String::verString()
{
    int cont = 0;
    while (this->Texto->largo_lista() > cont)
    {
        printf("%c",this->Texto->obtener(cont)->obtenerDato());
       //cout << this->Texto->obtener(cont)->obtenerDato() << endl;
       cont ++;
    }
}

int main()
{
    char variable[] = "Hola guapos";
    char nuevaCadena3[] = "Hola MUNDO!";
    
    String *p1 = new String(variable);
    p1->verString();
    cout << '\n';
    p1->cambiarCadena(nuevaCadena3);
    p1->verString();

    return 0;
}