#include <iostream>
#include <cstdlib>
#include "String.hpp"
using namespace std;
String::String(char*varTexto)
    {
        int cantidad = 0;
        this->Texto = new ListaEnlazada<char>();
        while(varTexto[cantidad] != '\0')
        {
            this->Texto->insertar(varTexto[cantidad]);
            cantidad +=1;
        }

    }
String::~String(){delete this->Texto;}
int longitud(char* var){
    int cont = 0;
    while (var[cont]!='\0'){
        cont +=1;
    }
    //cout << cont;
    return cont;
}
void String::concatenarEn(char* stringAConcatenar,int indice)
    {
        int longitudcadenaconca = longitud(stringAConcatenar);
        int contCadenaOriginal =  this->Texto->largo_lista();
        int cont = 0;
        int cont2 = 0;   
        int cont3 = 0;
        ListaEnlazada<char> *textoAnterior = new ListaEnlazada<char>();
        for (int i =0;i < contCadenaOriginal;i++)
        {
            textoAnterior->insertar(this->Texto->obtener(i)->obtenerDato());
        }
        this->Texto->~ListaEnlazada<char>();
        this->Texto = new ListaEnlazada<char>();
        int suma =  longitudcadenaconca + contCadenaOriginal ;
        while(cont3 < suma )
        {
            if (cont == indice)
            {
                while (cont2 < longitudcadenaconca)
                {
                    this->Texto->insertar(stringAConcatenar[cont2]);
                    cont2 +=1;
                    cont3 +=1;
                }
            }
                this->Texto->insertar(textoAnterior->obtener(cont)->obtenerDato());
                cont +=1;
                cont3 +=1; 
        }
        delete textoAnterior;
    }
    
void String::cambiarCadena(char* nuevaCadena)
    {
        this->Texto->~ListaEnlazada<char>();
        int cantidad = 0;
        this->Texto = new ListaEnlazada<char>();
        while(nuevaCadena[cantidad] != '\0')
        {
            this->Texto->insertar(nuevaCadena[cantidad]);
            cantidad +=1;
            
        }
    }

void String::ultimoIndice(char caracterABuscar)
    {
        int cont = (this->Texto->largo_lista())-1;
        while ((this->Texto->obtener(cont)->obtenerDato() != caracterABuscar))
        {
            cont -=1;
        }

        if (this->Texto->obtener(cont)->obtenerDato() == caracterABuscar){
        cout << "La ultima posicion del caracter indicado '" << caracterABuscar<< "' es la posicion : " << cont << endl;}
    }
void String::verString() {
    int cont = 0;
    // Imprime cada carácter hasta llegar al final de la lista
    while (cont < this->Texto->largo_lista()) {
        // Usa printf para imprimir el carácter
        printf("%c", this->Texto->obtener(cont)->obtenerDato());
        cont++;
    }
    // Añade un salto de línea al final
    printf("\n");
}


void String::len()
    {
        this->Texto->largo_lista2();
    }

int String::caracterABuscar(char BuscarCaracter)
    {
        int cont = 0;
        int frecuencia = 0;
        while (cont < this->Texto->largo_lista())
            {
                if (this->Texto->obtener(cont)->obtenerDato() == BuscarCaracter)
                    {
                        frecuencia +=1;
                    }
                cont +=1;
            }
        //cout <<frecuencia; 
        return frecuencia;  
    }
String** String::split(char caracterDeSplit)
{
    int cont = 0;
    int cont2 = 0;
    ListaEnlazada<char>* subcadena = new ListaEnlazada<char>();
    ListaEnlazada<String*>* subcadenas = new ListaEnlazada<String*>();

    while (cont < this->Texto->largo_lista())
    {
        char caracterActual = this->Texto->obtener(cont)->obtenerDato();

        if (caracterActual == caracterDeSplit)
        {
            if (subcadena->largo_lista() > 0) // Solo agregar subcadena no vacía
            {
                String* punteroAString = new String(subcadena->ConvertirAEstatico());
                subcadenas->insertar(punteroAString);
                delete subcadena;
                subcadena = new ListaEnlazada<char>(); // Reinicia subcadena
            }
        }
        else
        {
            subcadena->insertar(caracterActual);
        }

        cont++;
    }

    // Agrega la última subcadena si contiene caracteres
    if (subcadena->largo_lista() > 0)
    {
        String* punteroAString = new String(subcadena->ConvertirAEstatico());
        subcadenas->insertar(punteroAString);
    }

    delete subcadena; // Libera la memoria de la última subcadena

    // Convertir la lista de subcadenas a un arreglo estático de punteros a String
    int numSubcadenas = subcadenas->largo_lista();
    String** resultado = new String*[numSubcadenas + 1]; // +1 para el puntero nulo
    for (int i = 0; i < numSubcadenas; i++)
    {
        resultado[i] = subcadenas->obtener(i)->obtenerDato();
    }
    
    resultado[numSubcadenas] = nullptr; // Termina el arreglo con un nullptr
    delete subcadenas; // Libera la memoria de la lista de subcadenas
    return resultado;
    
}
void String::leerArchivo(char* ruta) 
    {
        FILE *archivo =  fopen(ruta , "r");
        char contenidoArch[3000];
        if (archivo == NULL) {
            printf("No se pudo abrir el archivo, revise la ruta ingresada.\n");
        } else {
            int cuentaBytesL = fread(contenidoArch, sizeof(char), 3000, archivo);
            contenidoArch[cuentaBytesL] = '\0';
            printf("Se hizo");
            fclose(archivo);
        }
        this->cambiarCadena(contenidoArch);
    }
int main() {
    char arreglo[5] = {'H','O','L','A','\0'};
    char variable[] = "Hola guapos";
    char nuevaCadena[] = "Adios";
    String *p1 = new String(variable);
    String *p2 = new String(arreglo);
    //p1->verString();
    std::cout << '\n';
    //p1->caracterABuscar('o');
    //String **resultadoSplit = nullptr;
    //resultadoSplit = p1->split('a');
    cout << "\n";
    //for (int i = 0; resultadoSplit[i] != nullptr; i++) resultadoSplit[i]->verString();
    char ruta[] = "./lectura.txt";
    p1->leerArchivo(ruta);
    cout << "\n";
    p1->verString();
    //p1->split('o');
    //p2->len();
    delete p1;
    delete p2;
    return 0;
}