#include "ListaEnlazada.hpp"
#include <iostream>

int main() {

    char variable[] = "Hola";
    char variable2[] = "Hala";
    char variable3[] = "Hola Mundo";
    // Crear una lista enlazada de enteros
    ListaEnlazada<char*> lista;

    // Insertar elementos en la lista
    lista.insertar(variable);
    lista.insertar(variable2);
    lista.insertar(variable3);
    
    // Imprimir la lista completa
    lista.eliminar(0);
    lista.largo_lista();
    std::cout << "Lista completa: " << std::endl;

    // lista.imprimir(); // Debería mostrar las direcciones de memoria de los nodos

    // Obtener y mostrar los elementos de la lista
    Nodo<char*>* nodo1 = lista.obtener(0);
    Nodo<char*>* nodo2 = lista.obtener(1);
    Nodo<char*>* nodo3 = lista.obtener(2);
    
   /* std::cout << "Valor del primer elemento: " << nodo1->obtenerDato() << std::endl;
    std::cout << "Valor del segundo elemento: " << nodo2->obtenerDato() << std::endl;
    std::cout << "Valor del tercer elemento: " << nodo3->obtenerDato() << std::endl;*/
    
    return 0;

    
}
