#include "ListaEnlazada.hpp"
#include <iostream>

using namespace std;
int main() {

    char variable[] = "Hola";
    char variable2[] = "Hala";
    char variable3[] = "Hola Mundo";
    // Crear una lista enlazada de enteros
    ListaEnlazada<char*> lista;

    // Insertar elementos en la lista
    lista.insertar(variable);
    lista.insertar(variable2);
    lista.insertar(variable3);

    lista.ConvertirAEstatico();
    
}
