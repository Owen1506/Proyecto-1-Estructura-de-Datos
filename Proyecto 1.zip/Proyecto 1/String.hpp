#ifndef String_HPP
#define String_HPP
#include "ListaEnlazada.hpp"
class String
{
private: 
     ListaEnlazada<char>* Texto;
public:
//Constructor y Destructor
    String(char *Texto);
    ~String();
//--------------------------------------------------------//
//Metodos
    void verString();
    int len(); //Listo
    void ultimoIndice(char); //
    void cambiarCadena(char*); //Listo
    void split(char);//Listo

};
#endif