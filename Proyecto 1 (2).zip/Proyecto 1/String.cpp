#include <iostream>
#include <cstdlib>
#include "String.hpp"
using namespace std;
String::String(char*varTexto)
    {
        int cantidad = 0;
        this->Texto = new ListaEnlazada<char>();
        while(varTexto[cantidad] != '\0')
        {
            this->Texto->insertar(varTexto[cantidad]);
            cantidad +=1;
        }

    }
String::~String(){delete this->Texto;}
int longitud(char* var){
    int cont = 0;
    while (var[cont]!='\0'){
        cont +=1;
    }
    //cout << cont;
    return cont;
}
void String::concatenarEn(char* stringAConcatenar,int indice)
    {
        int longitudcadenaconca = longitud(stringAConcatenar);
        int contCadenaOriginal =  this->Texto->largo_lista();
        int cont = 0;
        int cont2 = 0;   
        int cont3 = 0;
        ListaEnlazada<char> *textoAnterior = new ListaEnlazada<char>();
        for (int i =0;i < contCadenaOriginal;i++)
        {
            textoAnterior->insertar(this->Texto->obtener(i)->obtenerDato());
        }
        this->Texto->~ListaEnlazada<char>();
        this->Texto = new ListaEnlazada<char>();
        int suma =  longitudcadenaconca + contCadenaOriginal ;
        while(cont3 < suma )
        {
            if (cont == indice)
            {
                while (cont2 < longitudcadenaconca)
                {
                    this->Texto->insertar(stringAConcatenar[cont2]);
                    cont2 +=1;
                    cont3 +=1;
                }
            }
                this->Texto->insertar(textoAnterior->obtener(cont)->obtenerDato());
                cont +=1;
                cont3 +=1; 
        }
        delete textoAnterior;
    }
    
void String::cambiarCadena(char* nuevaCadena)
    {
        this->Texto->~ListaEnlazada<char>();
        int cantidad = 0;
        this->Texto = new ListaEnlazada<char>();
        while(nuevaCadena[cantidad] != '\0')
        {
            this->Texto->insertar(nuevaCadena[cantidad]);
            cantidad +=1;
            
        }
    }

void String::ultimoIndice(char caracterABuscar)
    {
        int cont = (this->Texto->largo_lista())-1;
        while ((this->Texto->obtener(cont)->obtenerDato() != caracterABuscar))
        {
            cont -=1;
        }

        if (this->Texto->obtener(cont)->obtenerDato() == caracterABuscar){
        cout << "La ultima posicion del caracter indicado '" << caracterABuscar<< "' es la posicion : " << cont << endl;}
    }
void String::verString()
    {
        int cont = 0;
        while (this->Texto->largo_lista() > cont)
        {
            printf("%c",this->Texto->obtener(cont)->obtenerDato());
        //cout << this->Texto->obtener(cont)->obtenerDato() << endl;
        cont ++;
        }
    }

void String::len()
    {
        this->Texto->largo_lista2();
    }
int main()
    {
        char variable[] = "Hola guapos";
        char nuevaCadena3[] = "Hola";
        String *p1 = new String(variable);
       p1->verString();
        cout << '\n';
        //p1->ultimoIndice('H');
        p1->concatenarEn(nuevaCadena3,5);
        p1->verString();
        return 0;
    }