#include "ListaEnlazada.hpp"
#include <iostream>
using namespace std;
int main() {

   char cadena1[] = "Hola, buZnos Rias\0";
  char cadena2[] = "hasta luAgo\0";
  char *cadenas[4] = {cadena1, cadena2, nullptr};

  cout << cadenas[1][13];

    
}
