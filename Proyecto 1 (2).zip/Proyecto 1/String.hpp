#ifndef String_HPP
#define String_HPP
#include "ListaEnlazada.hpp"
class String
{
private: 
     ListaEnlazada<char>* Texto;
public:
//Constructor y Destructor
    String(char *Texto);//Listo
    ~String();//Listo
//--------------------------------------------------------//
//Metodos
    void verString(); //Listo
    void len(); //Listo
    void ultimoIndice(char); // Listo
    void cambiarCadena(char*); //Listo
    void split(char);
    void concatenarEn(char*,int indice);//Listo

};
#endif